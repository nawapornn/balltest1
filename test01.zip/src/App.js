import React from 'react';
import ReactDOM from 'react-dom';
import './App.css'


const App = props => (
  <LoginForm />
);


class LoginForm extends React.Component{
render(){
  return(
    <div id="loginform">
      <FormHeader title="ฟอร์มล็อกอิน" />
      <Form />
      
    </div>
  )
}
}

const FormHeader = props => (
  <h2 id="headerTitle">{props.title}</h2>
);


const Form = props => (
 <div>
   <FormInput description="Username" placeholder="กรุณาใส่ username" 
   type="text" />
   <FormInput description="Password" placeholder="กรุณาใส่ password" 
   type="password"/>
   <FormButton title="ยืนยัน"/>
 </div>
);

const FormButton = props => (
<div id="button" class="row">
  <button>{props.title}</button>
</div>
);

const FormInput = props => (
<div class="row">
  <label>{props.description}</label>
  <input type={props.type} placeholder={props.placeholder}/>
</div>  
);

ReactDOM.render(<App />, document.getElementById('root'));

export default App;